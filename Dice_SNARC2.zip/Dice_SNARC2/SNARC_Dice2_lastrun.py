﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.2.3),
    on October 28, 2020, at 23:32
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.2.3'
expName = 'Digits vs. numerosity'  # from the Builder filename that created this script
expInfo = {'participant': '', 'gender': ['female', 'male'], 'age': '', 'handedness': ['left', 'right'], 'group': ['A', 'B']}
dlg = gui.DlgFromDict(dictionary=expInfo, sort_keys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\Yasmine\\Documents\\DMU\\Research assistant\\PsychoPy\\Dice_SNARC2\\SNARC_Dice2_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "welcome"
welcomeClock = core.Clock()
welcome_text = visual.TextStim(win=win, name='welcome_text',
    text="Welcome to this numerical task!             You will be presented with four blocks of trials. In two of the blocks you will be asked if the value of the digit is smaller or larger than 3.             In the other two blocks, you will be asked if the numerosity (The amount of digits present) is smaller/larger than 3.             Don't worry, you will get a chance to practice before the start of each block and you will be reminded of the instructions as well as how to respond.             When you are ready, press the spacebar to start.",
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
welcome_key_resp = keyboard.Keyboard()

# Initialize components for Routine "instructions"
instructionsClock = core.Clock()
Prac_Instruction = visual.TextStim(win=win, name='Prac_Instruction',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instr_key_resp = keyboard.Keyboard()

# Initialize components for Routine "practice_trial"
practice_trialClock = core.Clock()
fix_text = visual.TextStim(win=win, name='fix_text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
prac_num0 = visual.TextStim(win=win, name='prac_num0',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
prac_numA = visual.TextStim(win=win, name='prac_numA',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
prac_numB = visual.TextStim(win=win, name='prac_numB',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
prac_num1 = visual.TextStim(win=win, name='prac_num1',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);
prac_num2 = visual.TextStim(win=win, name='prac_num2',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
prac_num3 = visual.TextStim(win=win, name='prac_num3',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
prac_num4 = visual.TextStim(win=win, name='prac_num4',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
practice_trial_key_resp = keyboard.Keyboard()

# Initialize components for Routine "practice_feed"
practice_feedClock = core.Clock()
msg_text = visual.TextStim(win=win, name='msg_text',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "exp_intro"
exp_introClock = core.Clock()
exp_intro_text = visual.TextStim(win=win, name='exp_intro_text',
    text='Good! You have completed the practice trials for this block and will now do the real trials.             Remember, this time you will not be recieving feedback on your responses.             Good luck! Press the spacebar to begin.',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
exp_sess_intro_key_resp = keyboard.Keyboard()

# Initialize components for Routine "exp_sess_trial"
exp_sess_trialClock = core.Clock()
exp_fix_text = visual.TextStim(win=win, name='exp_fix_text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
exp_num0 = visual.TextStim(win=win, name='exp_num0',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
exp_numA = visual.TextStim(win=win, name='exp_numA',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
exp_numB = visual.TextStim(win=win, name='exp_numB',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
exp_num1 = visual.TextStim(win=win, name='exp_num1',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-4.0);
exp_num2 = visual.TextStim(win=win, name='exp_num2',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
exp_num3 = visual.TextStim(win=win, name='exp_num3',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
exp_num4 = visual.TextStim(win=win, name='exp_num4',
    text='default text',
    font='Arial',
    pos=[0,0], height=0.08, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
exp_number_key_resp = keyboard.Keyboard()

# Initialize components for Routine "break_3"
break_3Clock = core.Clock()
newBlock_text = visual.TextStim(win=win, name='newBlock_text',
    text='You have finished this block of trials. Well done!         You will now be continuing on to the next block.         Please press the spacebar when you are ready to begin the practice.',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
newBlock_key_resp = keyboard.Keyboard()

# Initialize components for Routine "end"
endClock = core.Clock()
end_text = visual.TextStim(win=win, name='end_text',
    text='Congratulations! \nYou have reached the end of study.             Thank you for your participation!',
    font='Arial',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "welcome"-------
continueRoutine = True
# update component parameters for each repeat
welcome_key_resp.keys = []
welcome_key_resp.rt = []
_welcome_key_resp_allKeys = []
# keep track of which components have finished
welcomeComponents = [welcome_text, welcome_key_resp]
for thisComponent in welcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
welcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "welcome"-------
while continueRoutine:
    # get current time
    t = welcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=welcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcome_text* updates
    if welcome_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        welcome_text.frameNStart = frameN  # exact frame index
        welcome_text.tStart = t  # local t and not account for scr refresh
        welcome_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_text, 'tStartRefresh')  # time at next scr refresh
        welcome_text.setAutoDraw(True)
    
    # *welcome_key_resp* updates
    waitOnFlip = False
    if welcome_key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        welcome_key_resp.frameNStart = frameN  # exact frame index
        welcome_key_resp.tStart = t  # local t and not account for scr refresh
        welcome_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_key_resp, 'tStartRefresh')  # time at next scr refresh
        welcome_key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(welcome_key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(welcome_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if welcome_key_resp.status == STARTED and not waitOnFlip:
        theseKeys = welcome_key_resp.getKeys(keyList=['space'], waitRelease=False)
        _welcome_key_resp_allKeys.extend(theseKeys)
        if len(_welcome_key_resp_allKeys):
            welcome_key_resp.keys = _welcome_key_resp_allKeys[-1].name  # just the last key pressed
            welcome_key_resp.rt = _welcome_key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "welcome"-------
for thisComponent in welcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('welcome_text.started', welcome_text.tStartRefresh)
thisExp.addData('welcome_text.stopped', welcome_text.tStopRefresh)
# check responses
if welcome_key_resp.keys in ['', [], None]:  # No response was made
    welcome_key_resp.keys = None
thisExp.addData('welcome_key_resp.keys',welcome_key_resp.keys)
if welcome_key_resp.keys != None:  # we had a response
    thisExp.addData('welcome_key_resp.rt', welcome_key_resp.rt)
thisExp.addData('welcome_key_resp.started', welcome_key_resp.tStartRefresh)
thisExp.addData('welcome_key_resp.stopped', welcome_key_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
blocks = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('group' + expInfo['group'] + '.xlsx'),
    seed=None, name='blocks')
thisExp.addLoop(blocks)  # add the loop to the experiment
thisBlock = blocks.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
if thisBlock != None:
    for paramName in thisBlock:
        exec('{} = thisBlock[paramName]'.format(paramName))

for thisBlock in blocks:
    currentLoop = blocks
    # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
    if thisBlock != None:
        for paramName in thisBlock:
            exec('{} = thisBlock[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "instructions"-------
    continueRoutine = True
    # update component parameters for each repeat
    Prac_Instruction.setText(inst)
    instr_key_resp.keys = []
    instr_key_resp.rt = []
    _instr_key_resp_allKeys = []
    # keep track of which components have finished
    instructionsComponents = [Prac_Instruction, instr_key_resp]
    for thisComponent in instructionsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    instructionsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "instructions"-------
    while continueRoutine:
        # get current time
        t = instructionsClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=instructionsClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Prac_Instruction* updates
        if Prac_Instruction.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            Prac_Instruction.frameNStart = frameN  # exact frame index
            Prac_Instruction.tStart = t  # local t and not account for scr refresh
            Prac_Instruction.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Prac_Instruction, 'tStartRefresh')  # time at next scr refresh
            Prac_Instruction.setAutoDraw(True)
        
        # *instr_key_resp* updates
        waitOnFlip = False
        if instr_key_resp.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            instr_key_resp.frameNStart = frameN  # exact frame index
            instr_key_resp.tStart = t  # local t and not account for scr refresh
            instr_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instr_key_resp, 'tStartRefresh')  # time at next scr refresh
            instr_key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instr_key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instr_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instr_key_resp.status == STARTED and not waitOnFlip:
            theseKeys = instr_key_resp.getKeys(keyList=['space'], waitRelease=False)
            _instr_key_resp_allKeys.extend(theseKeys)
            if len(_instr_key_resp_allKeys):
                instr_key_resp.keys = _instr_key_resp_allKeys[-1].name  # just the last key pressed
                instr_key_resp.rt = _instr_key_resp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructionsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "instructions"-------
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    blocks.addData('Prac_Instruction.started', Prac_Instruction.tStartRefresh)
    blocks.addData('Prac_Instruction.stopped', Prac_Instruction.tStopRefresh)
    # check responses
    if instr_key_resp.keys in ['', [], None]:  # No response was made
        instr_key_resp.keys = None
    blocks.addData('instr_key_resp.keys',instr_key_resp.keys)
    if instr_key_resp.keys != None:  # we had a response
        blocks.addData('instr_key_resp.rt', instr_key_resp.rt)
    blocks.addData('instr_key_resp.started', instr_key_resp.tStartRefresh)
    blocks.addData('instr_key_resp.stopped', instr_key_resp.tStopRefresh)
    # the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice_trials = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(order),
        seed=None, name='practice_trials')
    thisExp.addLoop(practice_trials)  # add the loop to the experiment
    thisPractice_trial = practice_trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
    if thisPractice_trial != None:
        for paramName in thisPractice_trial:
            exec('{} = thisPractice_trial[paramName]'.format(paramName))
    
    for thisPractice_trial in practice_trials:
        currentLoop = practice_trials
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
        if thisPractice_trial != None:
            for paramName in thisPractice_trial:
                exec('{} = thisPractice_trial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "practice_trial"-------
        continueRoutine = True
        routineTimer.add(4.500000)
        # update component parameters for each repeat
        prac_num0.setPos(eval(pos0))
        prac_num0.setText(number)
        prac_numA.setPos(eval(posA))
        prac_numA.setText(number)
        prac_numB.setPos(eval(posB))
        prac_numB.setText(number)
        prac_num1.setPos(eval(pos1))
        prac_num1.setText(number)
        prac_num2.setPos(eval(pos2))
        prac_num2.setText(number)
        prac_num3.setPos(eval(pos3))
        prac_num3.setText(number)
        prac_num4.setPos(eval(pos4))
        prac_num4.setText(number)
        practice_trial_key_resp.keys = []
        practice_trial_key_resp.rt = []
        _practice_trial_key_resp_allKeys = []
        # keep track of which components have finished
        practice_trialComponents = [fix_text, prac_num0, prac_numA, prac_numB, prac_num1, prac_num2, prac_num3, prac_num4, practice_trial_key_resp]
        for thisComponent in practice_trialComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        practice_trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "practice_trial"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = practice_trialClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=practice_trialClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fix_text* updates
            if fix_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                fix_text.frameNStart = frameN  # exact frame index
                fix_text.tStart = t  # local t and not account for scr refresh
                fix_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fix_text, 'tStartRefresh')  # time at next scr refresh
                fix_text.setAutoDraw(True)
            if fix_text.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fix_text.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fix_text.tStop = t  # not accounting for scr refresh
                    fix_text.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fix_text, 'tStopRefresh')  # time at next scr refresh
                    fix_text.setAutoDraw(False)
            
            # *prac_num0* updates
            if prac_num0.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_num0.frameNStart = frameN  # exact frame index
                prac_num0.tStart = t  # local t and not account for scr refresh
                prac_num0.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_num0, 'tStartRefresh')  # time at next scr refresh
                prac_num0.setAutoDraw(True)
            if prac_num0.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_num0.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_num0.tStop = t  # not accounting for scr refresh
                    prac_num0.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_num0, 'tStopRefresh')  # time at next scr refresh
                    prac_num0.setAutoDraw(False)
            
            # *prac_numA* updates
            if prac_numA.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_numA.frameNStart = frameN  # exact frame index
                prac_numA.tStart = t  # local t and not account for scr refresh
                prac_numA.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_numA, 'tStartRefresh')  # time at next scr refresh
                prac_numA.setAutoDraw(True)
            if prac_numA.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_numA.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_numA.tStop = t  # not accounting for scr refresh
                    prac_numA.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_numA, 'tStopRefresh')  # time at next scr refresh
                    prac_numA.setAutoDraw(False)
            
            # *prac_numB* updates
            if prac_numB.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_numB.frameNStart = frameN  # exact frame index
                prac_numB.tStart = t  # local t and not account for scr refresh
                prac_numB.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_numB, 'tStartRefresh')  # time at next scr refresh
                prac_numB.setAutoDraw(True)
            if prac_numB.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_numB.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_numB.tStop = t  # not accounting for scr refresh
                    prac_numB.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_numB, 'tStopRefresh')  # time at next scr refresh
                    prac_numB.setAutoDraw(False)
            
            # *prac_num1* updates
            if prac_num1.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_num1.frameNStart = frameN  # exact frame index
                prac_num1.tStart = t  # local t and not account for scr refresh
                prac_num1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_num1, 'tStartRefresh')  # time at next scr refresh
                prac_num1.setAutoDraw(True)
            if prac_num1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_num1.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_num1.tStop = t  # not accounting for scr refresh
                    prac_num1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_num1, 'tStopRefresh')  # time at next scr refresh
                    prac_num1.setAutoDraw(False)
            
            # *prac_num2* updates
            if prac_num2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_num2.frameNStart = frameN  # exact frame index
                prac_num2.tStart = t  # local t and not account for scr refresh
                prac_num2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_num2, 'tStartRefresh')  # time at next scr refresh
                prac_num2.setAutoDraw(True)
            if prac_num2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_num2.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_num2.tStop = t  # not accounting for scr refresh
                    prac_num2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_num2, 'tStopRefresh')  # time at next scr refresh
                    prac_num2.setAutoDraw(False)
            
            # *prac_num3* updates
            if prac_num3.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_num3.frameNStart = frameN  # exact frame index
                prac_num3.tStart = t  # local t and not account for scr refresh
                prac_num3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_num3, 'tStartRefresh')  # time at next scr refresh
                prac_num3.setAutoDraw(True)
            if prac_num3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_num3.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_num3.tStop = t  # not accounting for scr refresh
                    prac_num3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_num3, 'tStopRefresh')  # time at next scr refresh
                    prac_num3.setAutoDraw(False)
            
            # *prac_num4* updates
            if prac_num4.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                prac_num4.frameNStart = frameN  # exact frame index
                prac_num4.tStart = t  # local t and not account for scr refresh
                prac_num4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_num4, 'tStartRefresh')  # time at next scr refresh
                prac_num4.setAutoDraw(True)
            if prac_num4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_num4.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_num4.tStop = t  # not accounting for scr refresh
                    prac_num4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(prac_num4, 'tStopRefresh')  # time at next scr refresh
                    prac_num4.setAutoDraw(False)
            
            # *practice_trial_key_resp* updates
            waitOnFlip = False
            if practice_trial_key_resp.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                practice_trial_key_resp.frameNStart = frameN  # exact frame index
                practice_trial_key_resp.tStart = t  # local t and not account for scr refresh
                practice_trial_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practice_trial_key_resp, 'tStartRefresh')  # time at next scr refresh
                practice_trial_key_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(practice_trial_key_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(practice_trial_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if practice_trial_key_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > practice_trial_key_resp.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    practice_trial_key_resp.tStop = t  # not accounting for scr refresh
                    practice_trial_key_resp.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(practice_trial_key_resp, 'tStopRefresh')  # time at next scr refresh
                    practice_trial_key_resp.status = FINISHED
            if practice_trial_key_resp.status == STARTED and not waitOnFlip:
                theseKeys = practice_trial_key_resp.getKeys(keyList=['a', 'l'], waitRelease=False)
                _practice_trial_key_resp_allKeys.extend(theseKeys)
                if len(_practice_trial_key_resp_allKeys):
                    practice_trial_key_resp.keys = _practice_trial_key_resp_allKeys[-1].name  # just the last key pressed
                    practice_trial_key_resp.rt = _practice_trial_key_resp_allKeys[-1].rt
                    # was this correct?
                    if (practice_trial_key_resp.keys == str(correctkey)) or (practice_trial_key_resp.keys == correctkey):
                        practice_trial_key_resp.corr = 1
                    else:
                        practice_trial_key_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in practice_trialComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "practice_trial"-------
        for thisComponent in practice_trialComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        practice_trials.addData('fix_text.started', fix_text.tStartRefresh)
        practice_trials.addData('fix_text.stopped', fix_text.tStopRefresh)
        practice_trials.addData('prac_num0.started', prac_num0.tStartRefresh)
        practice_trials.addData('prac_num0.stopped', prac_num0.tStopRefresh)
        practice_trials.addData('prac_numA.started', prac_numA.tStartRefresh)
        practice_trials.addData('prac_numA.stopped', prac_numA.tStopRefresh)
        practice_trials.addData('prac_numB.started', prac_numB.tStartRefresh)
        practice_trials.addData('prac_numB.stopped', prac_numB.tStopRefresh)
        practice_trials.addData('prac_num1.started', prac_num1.tStartRefresh)
        practice_trials.addData('prac_num1.stopped', prac_num1.tStopRefresh)
        practice_trials.addData('prac_num2.started', prac_num2.tStartRefresh)
        practice_trials.addData('prac_num2.stopped', prac_num2.tStopRefresh)
        practice_trials.addData('prac_num3.started', prac_num3.tStartRefresh)
        practice_trials.addData('prac_num3.stopped', prac_num3.tStopRefresh)
        practice_trials.addData('prac_num4.started', prac_num4.tStartRefresh)
        practice_trials.addData('prac_num4.stopped', prac_num4.tStopRefresh)
        # check responses
        if practice_trial_key_resp.keys in ['', [], None]:  # No response was made
            practice_trial_key_resp.keys = None
            # was no response the correct answer?!
            if str(correctkey).lower() == 'none':
               practice_trial_key_resp.corr = 1;  # correct non-response
            else:
               practice_trial_key_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for practice_trials (TrialHandler)
        practice_trials.addData('practice_trial_key_resp.keys',practice_trial_key_resp.keys)
        practice_trials.addData('practice_trial_key_resp.corr', practice_trial_key_resp.corr)
        if practice_trial_key_resp.keys != None:  # we had a response
            practice_trials.addData('practice_trial_key_resp.rt', practice_trial_key_resp.rt)
        practice_trials.addData('practice_trial_key_resp.started', practice_trial_key_resp.tStartRefresh)
        practice_trials.addData('practice_trial_key_resp.stopped', practice_trial_key_resp.tStopRefresh)
        
        # ------Prepare to start Routine "practice_feed"-------
        continueRoutine = True
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        if practice_trial_key_resp.corr:#stored on last run routine
          msg="Correct! RT=%.3f" %(practice_trial_key_resp.rt)
        else:
          msg="Oops!"
        msg_text.setText(msg)
        # keep track of which components have finished
        practice_feedComponents = [msg_text]
        for thisComponent in practice_feedComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        practice_feedClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "practice_feed"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = practice_feedClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=practice_feedClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *msg_text* updates
            if msg_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                msg_text.frameNStart = frameN  # exact frame index
                msg_text.tStart = t  # local t and not account for scr refresh
                msg_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(msg_text, 'tStartRefresh')  # time at next scr refresh
                msg_text.setAutoDraw(True)
            if msg_text.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > msg_text.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    msg_text.tStop = t  # not accounting for scr refresh
                    msg_text.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(msg_text, 'tStopRefresh')  # time at next scr refresh
                    msg_text.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in practice_feedComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "practice_feed"-------
        for thisComponent in practice_feedComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        practice_trials.addData('msg_text.started', msg_text.tStartRefresh)
        practice_trials.addData('msg_text.stopped', msg_text.tStopRefresh)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'practice_trials'
    
    # get names of stimulus parameters
    if practice_trials.trialList in ([], [None], None):
        params = []
    else:
        params = practice_trials.trialList[0].keys()
    # save data for this loop
    practice_trials.saveAsExcel(filename + '.xlsx', sheetName='practice_trials',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # ------Prepare to start Routine "exp_intro"-------
    continueRoutine = True
    # update component parameters for each repeat
    exp_sess_intro_key_resp.keys = []
    exp_sess_intro_key_resp.rt = []
    _exp_sess_intro_key_resp_allKeys = []
    # keep track of which components have finished
    exp_introComponents = [exp_intro_text, exp_sess_intro_key_resp]
    for thisComponent in exp_introComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    exp_introClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "exp_intro"-------
    while continueRoutine:
        # get current time
        t = exp_introClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=exp_introClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *exp_intro_text* updates
        if exp_intro_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            exp_intro_text.frameNStart = frameN  # exact frame index
            exp_intro_text.tStart = t  # local t and not account for scr refresh
            exp_intro_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(exp_intro_text, 'tStartRefresh')  # time at next scr refresh
            exp_intro_text.setAutoDraw(True)
        
        # *exp_sess_intro_key_resp* updates
        waitOnFlip = False
        if exp_sess_intro_key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            exp_sess_intro_key_resp.frameNStart = frameN  # exact frame index
            exp_sess_intro_key_resp.tStart = t  # local t and not account for scr refresh
            exp_sess_intro_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(exp_sess_intro_key_resp, 'tStartRefresh')  # time at next scr refresh
            exp_sess_intro_key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(exp_sess_intro_key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(exp_sess_intro_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if exp_sess_intro_key_resp.status == STARTED and not waitOnFlip:
            theseKeys = exp_sess_intro_key_resp.getKeys(keyList=['space'], waitRelease=False)
            _exp_sess_intro_key_resp_allKeys.extend(theseKeys)
            if len(_exp_sess_intro_key_resp_allKeys):
                exp_sess_intro_key_resp.keys = _exp_sess_intro_key_resp_allKeys[-1].name  # just the last key pressed
                exp_sess_intro_key_resp.rt = _exp_sess_intro_key_resp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in exp_introComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "exp_intro"-------
    for thisComponent in exp_introComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    blocks.addData('exp_intro_text.started', exp_intro_text.tStartRefresh)
    blocks.addData('exp_intro_text.stopped', exp_intro_text.tStopRefresh)
    # check responses
    if exp_sess_intro_key_resp.keys in ['', [], None]:  # No response was made
        exp_sess_intro_key_resp.keys = None
    blocks.addData('exp_sess_intro_key_resp.keys',exp_sess_intro_key_resp.keys)
    if exp_sess_intro_key_resp.keys != None:  # we had a response
        blocks.addData('exp_sess_intro_key_resp.rt', exp_sess_intro_key_resp.rt)
    blocks.addData('exp_sess_intro_key_resp.started', exp_sess_intro_key_resp.tStartRefresh)
    blocks.addData('exp_sess_intro_key_resp.stopped', exp_sess_intro_key_resp.tStopRefresh)
    # the Routine "exp_intro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    exp_sess_trials = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(order),
        seed=None, name='exp_sess_trials')
    thisExp.addLoop(exp_sess_trials)  # add the loop to the experiment
    thisExp_sess_trial = exp_sess_trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExp_sess_trial.rgb)
    if thisExp_sess_trial != None:
        for paramName in thisExp_sess_trial:
            exec('{} = thisExp_sess_trial[paramName]'.format(paramName))
    
    for thisExp_sess_trial in exp_sess_trials:
        currentLoop = exp_sess_trials
        # abbreviate parameter names if possible (e.g. rgb = thisExp_sess_trial.rgb)
        if thisExp_sess_trial != None:
            for paramName in thisExp_sess_trial:
                exec('{} = thisExp_sess_trial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "exp_sess_trial"-------
        continueRoutine = True
        routineTimer.add(4.500000)
        # update component parameters for each repeat
        exp_num0.setPos(eval(pos0))
        exp_num0.setText(number)
        exp_numA.setPos(eval(posA))
        exp_numA.setText(number)
        exp_numB.setPos(eval(posB))
        exp_numB.setText(number)
        exp_num1.setPos(eval(pos1))
        exp_num1.setText(number)
        exp_num2.setPos(eval(pos2))
        exp_num2.setText(number)
        exp_num3.setPos(eval(pos3))
        exp_num3.setText(number)
        exp_num4.setPos(eval(pos4))
        exp_num4.setText(number)
        exp_number_key_resp.keys = []
        exp_number_key_resp.rt = []
        _exp_number_key_resp_allKeys = []
        # keep track of which components have finished
        exp_sess_trialComponents = [exp_fix_text, exp_num0, exp_numA, exp_numB, exp_num1, exp_num2, exp_num3, exp_num4, exp_number_key_resp]
        for thisComponent in exp_sess_trialComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        exp_sess_trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "exp_sess_trial"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = exp_sess_trialClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=exp_sess_trialClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *exp_fix_text* updates
            if exp_fix_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                exp_fix_text.frameNStart = frameN  # exact frame index
                exp_fix_text.tStart = t  # local t and not account for scr refresh
                exp_fix_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_fix_text, 'tStartRefresh')  # time at next scr refresh
                exp_fix_text.setAutoDraw(True)
            if exp_fix_text.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_fix_text.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_fix_text.tStop = t  # not accounting for scr refresh
                    exp_fix_text.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_fix_text, 'tStopRefresh')  # time at next scr refresh
                    exp_fix_text.setAutoDraw(False)
            
            # *exp_num0* updates
            if exp_num0.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_num0.frameNStart = frameN  # exact frame index
                exp_num0.tStart = t  # local t and not account for scr refresh
                exp_num0.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_num0, 'tStartRefresh')  # time at next scr refresh
                exp_num0.setAutoDraw(True)
            if exp_num0.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_num0.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_num0.tStop = t  # not accounting for scr refresh
                    exp_num0.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_num0, 'tStopRefresh')  # time at next scr refresh
                    exp_num0.setAutoDraw(False)
            
            # *exp_numA* updates
            if exp_numA.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_numA.frameNStart = frameN  # exact frame index
                exp_numA.tStart = t  # local t and not account for scr refresh
                exp_numA.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_numA, 'tStartRefresh')  # time at next scr refresh
                exp_numA.setAutoDraw(True)
            if exp_numA.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_numA.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_numA.tStop = t  # not accounting for scr refresh
                    exp_numA.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_numA, 'tStopRefresh')  # time at next scr refresh
                    exp_numA.setAutoDraw(False)
            
            # *exp_numB* updates
            if exp_numB.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_numB.frameNStart = frameN  # exact frame index
                exp_numB.tStart = t  # local t and not account for scr refresh
                exp_numB.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_numB, 'tStartRefresh')  # time at next scr refresh
                exp_numB.setAutoDraw(True)
            if exp_numB.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_numB.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_numB.tStop = t  # not accounting for scr refresh
                    exp_numB.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_numB, 'tStopRefresh')  # time at next scr refresh
                    exp_numB.setAutoDraw(False)
            
            # *exp_num1* updates
            if exp_num1.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_num1.frameNStart = frameN  # exact frame index
                exp_num1.tStart = t  # local t and not account for scr refresh
                exp_num1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_num1, 'tStartRefresh')  # time at next scr refresh
                exp_num1.setAutoDraw(True)
            if exp_num1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_num1.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_num1.tStop = t  # not accounting for scr refresh
                    exp_num1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_num1, 'tStopRefresh')  # time at next scr refresh
                    exp_num1.setAutoDraw(False)
            
            # *exp_num2* updates
            if exp_num2.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_num2.frameNStart = frameN  # exact frame index
                exp_num2.tStart = t  # local t and not account for scr refresh
                exp_num2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_num2, 'tStartRefresh')  # time at next scr refresh
                exp_num2.setAutoDraw(True)
            if exp_num2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_num2.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_num2.tStop = t  # not accounting for scr refresh
                    exp_num2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_num2, 'tStopRefresh')  # time at next scr refresh
                    exp_num2.setAutoDraw(False)
            
            # *exp_num3* updates
            if exp_num3.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_num3.frameNStart = frameN  # exact frame index
                exp_num3.tStart = t  # local t and not account for scr refresh
                exp_num3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_num3, 'tStartRefresh')  # time at next scr refresh
                exp_num3.setAutoDraw(True)
            if exp_num3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_num3.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_num3.tStop = t  # not accounting for scr refresh
                    exp_num3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_num3, 'tStopRefresh')  # time at next scr refresh
                    exp_num3.setAutoDraw(False)
            
            # *exp_num4* updates
            if exp_num4.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_num4.frameNStart = frameN  # exact frame index
                exp_num4.tStart = t  # local t and not account for scr refresh
                exp_num4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_num4, 'tStartRefresh')  # time at next scr refresh
                exp_num4.setAutoDraw(True)
            if exp_num4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_num4.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_num4.tStop = t  # not accounting for scr refresh
                    exp_num4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_num4, 'tStopRefresh')  # time at next scr refresh
                    exp_num4.setAutoDraw(False)
            
            # *exp_number_key_resp* updates
            waitOnFlip = False
            if exp_number_key_resp.status == NOT_STARTED and tThisFlip >= 1.5-frameTolerance:
                # keep track of start time/frame for later
                exp_number_key_resp.frameNStart = frameN  # exact frame index
                exp_number_key_resp.tStart = t  # local t and not account for scr refresh
                exp_number_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(exp_number_key_resp, 'tStartRefresh')  # time at next scr refresh
                exp_number_key_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(exp_number_key_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(exp_number_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if exp_number_key_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > exp_number_key_resp.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    exp_number_key_resp.tStop = t  # not accounting for scr refresh
                    exp_number_key_resp.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(exp_number_key_resp, 'tStopRefresh')  # time at next scr refresh
                    exp_number_key_resp.status = FINISHED
            if exp_number_key_resp.status == STARTED and not waitOnFlip:
                theseKeys = exp_number_key_resp.getKeys(keyList=['a', 'l'], waitRelease=False)
                _exp_number_key_resp_allKeys.extend(theseKeys)
                if len(_exp_number_key_resp_allKeys):
                    exp_number_key_resp.keys = _exp_number_key_resp_allKeys[-1].name  # just the last key pressed
                    exp_number_key_resp.rt = _exp_number_key_resp_allKeys[-1].rt
                    # was this correct?
                    if (exp_number_key_resp.keys == str(correctkey)) or (exp_number_key_resp.keys == correctkey):
                        exp_number_key_resp.corr = 1
                    else:
                        exp_number_key_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in exp_sess_trialComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "exp_sess_trial"-------
        for thisComponent in exp_sess_trialComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        exp_sess_trials.addData('exp_fix_text.started', exp_fix_text.tStartRefresh)
        exp_sess_trials.addData('exp_fix_text.stopped', exp_fix_text.tStopRefresh)
        exp_sess_trials.addData('exp_num0.started', exp_num0.tStartRefresh)
        exp_sess_trials.addData('exp_num0.stopped', exp_num0.tStopRefresh)
        exp_sess_trials.addData('exp_numA.started', exp_numA.tStartRefresh)
        exp_sess_trials.addData('exp_numA.stopped', exp_numA.tStopRefresh)
        exp_sess_trials.addData('exp_numB.started', exp_numB.tStartRefresh)
        exp_sess_trials.addData('exp_numB.stopped', exp_numB.tStopRefresh)
        exp_sess_trials.addData('exp_num1.started', exp_num1.tStartRefresh)
        exp_sess_trials.addData('exp_num1.stopped', exp_num1.tStopRefresh)
        exp_sess_trials.addData('exp_num2.started', exp_num2.tStartRefresh)
        exp_sess_trials.addData('exp_num2.stopped', exp_num2.tStopRefresh)
        exp_sess_trials.addData('exp_num3.started', exp_num3.tStartRefresh)
        exp_sess_trials.addData('exp_num3.stopped', exp_num3.tStopRefresh)
        exp_sess_trials.addData('exp_num4.started', exp_num4.tStartRefresh)
        exp_sess_trials.addData('exp_num4.stopped', exp_num4.tStopRefresh)
        # check responses
        if exp_number_key_resp.keys in ['', [], None]:  # No response was made
            exp_number_key_resp.keys = None
            # was no response the correct answer?!
            if str(correctkey).lower() == 'none':
               exp_number_key_resp.corr = 1;  # correct non-response
            else:
               exp_number_key_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for exp_sess_trials (TrialHandler)
        exp_sess_trials.addData('exp_number_key_resp.keys',exp_number_key_resp.keys)
        exp_sess_trials.addData('exp_number_key_resp.corr', exp_number_key_resp.corr)
        if exp_number_key_resp.keys != None:  # we had a response
            exp_sess_trials.addData('exp_number_key_resp.rt', exp_number_key_resp.rt)
        exp_sess_trials.addData('exp_number_key_resp.started', exp_number_key_resp.tStartRefresh)
        exp_sess_trials.addData('exp_number_key_resp.stopped', exp_number_key_resp.tStopRefresh)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'exp_sess_trials'
    
    # get names of stimulus parameters
    if exp_sess_trials.trialList in ([], [None], None):
        params = []
    else:
        params = exp_sess_trials.trialList[0].keys()
    # save data for this loop
    exp_sess_trials.saveAsExcel(filename + '.xlsx', sheetName='exp_sess_trials',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # ------Prepare to start Routine "break_3"-------
    continueRoutine = True
    # update component parameters for each repeat
    newBlock_key_resp.keys = []
    newBlock_key_resp.rt = []
    _newBlock_key_resp_allKeys = []
    # keep track of which components have finished
    break_3Components = [newBlock_text, newBlock_key_resp]
    for thisComponent in break_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    break_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "break_3"-------
    while continueRoutine:
        # get current time
        t = break_3Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=break_3Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *newBlock_text* updates
        if newBlock_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            newBlock_text.frameNStart = frameN  # exact frame index
            newBlock_text.tStart = t  # local t and not account for scr refresh
            newBlock_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(newBlock_text, 'tStartRefresh')  # time at next scr refresh
            newBlock_text.setAutoDraw(True)
        
        # *newBlock_key_resp* updates
        waitOnFlip = False
        if newBlock_key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            newBlock_key_resp.frameNStart = frameN  # exact frame index
            newBlock_key_resp.tStart = t  # local t and not account for scr refresh
            newBlock_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(newBlock_key_resp, 'tStartRefresh')  # time at next scr refresh
            newBlock_key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(newBlock_key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(newBlock_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if newBlock_key_resp.status == STARTED and not waitOnFlip:
            theseKeys = newBlock_key_resp.getKeys(keyList=['space'], waitRelease=False)
            _newBlock_key_resp_allKeys.extend(theseKeys)
            if len(_newBlock_key_resp_allKeys):
                newBlock_key_resp.keys = _newBlock_key_resp_allKeys[-1].name  # just the last key pressed
                newBlock_key_resp.rt = _newBlock_key_resp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in break_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "break_3"-------
    for thisComponent in break_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    blocks.addData('newBlock_text.started', newBlock_text.tStartRefresh)
    blocks.addData('newBlock_text.stopped', newBlock_text.tStopRefresh)
    # check responses
    if newBlock_key_resp.keys in ['', [], None]:  # No response was made
        newBlock_key_resp.keys = None
    blocks.addData('newBlock_key_resp.keys',newBlock_key_resp.keys)
    if newBlock_key_resp.keys != None:  # we had a response
        blocks.addData('newBlock_key_resp.rt', newBlock_key_resp.rt)
    blocks.addData('newBlock_key_resp.started', newBlock_key_resp.tStartRefresh)
    blocks.addData('newBlock_key_resp.stopped', newBlock_key_resp.tStopRefresh)
    # the Routine "break_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'blocks'

# get names of stimulus parameters
if blocks.trialList in ([], [None], None):
    params = []
else:
    params = blocks.trialList[0].keys()
# save data for this loop
blocks.saveAsExcel(filename + '.xlsx', sheetName='blocks',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "end"-------
continueRoutine = True
routineTimer.add(10.500000)
# update component parameters for each repeat
# keep track of which components have finished
endComponents = [end_text]
for thisComponent in endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
endClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "end"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = endClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=endClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *end_text* updates
    if end_text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
        # keep track of start time/frame for later
        end_text.frameNStart = frameN  # exact frame index
        end_text.tStart = t  # local t and not account for scr refresh
        end_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(end_text, 'tStartRefresh')  # time at next scr refresh
        end_text.setAutoDraw(True)
    if end_text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > end_text.tStartRefresh + 10-frameTolerance:
            # keep track of stop time/frame for later
            end_text.tStop = t  # not accounting for scr refresh
            end_text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(end_text, 'tStopRefresh')  # time at next scr refresh
            end_text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "end"-------
for thisComponent in endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('end_text.started', end_text.tStartRefresh)
thisExp.addData('end_text.stopped', end_text.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
