﻿/******************** 
 * Snarc_Dice2 Test *
 ********************/

import { PsychoJS } from './lib/core-2020.2.js';
import * as core from './lib/core-2020.2.js';
import { TrialHandler } from './lib/data-2020.2.js';
import { Scheduler } from './lib/util-2020.2.js';
import * as visual from './lib/visual-2020.2.js';
import * as sound from './lib/sound-2020.2.js';
import * as util from './lib/util-2020.2.js';
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;

// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0, 0, 0]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'SNARC_Dice2';  // from the Builder filename that created this script
let expInfo = {'participant': '', 'gender': ['female', 'male'], 'age': '', 'handedness': ['left', 'right'], 'group': ['A', 'B']};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(welcomeRoutineBegin());
flowScheduler.add(welcomeRoutineEachFrame());
flowScheduler.add(welcomeRoutineEnd());
const blocksLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(blocksLoopBegin, blocksLoopScheduler);
flowScheduler.add(blocksLoopScheduler);
flowScheduler.add(blocksLoopEnd);
flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  });


var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2020.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}


var welcomeClock;
var welcome_text;
var welcome_key_resp;
var instructionsClock;
var Prac_Instruction;
var instr_key_resp;
var practice_trialClock;
var fix_text;
var prac_num0;
var prac_numA;
var prac_numB;
var prac_num1;
var prac_num2;
var prac_num3;
var prac_num4;
var practice_trial_key_resp;
var practice_feedClock;
var msg_text;
var exp_introClock;
var exp_intro_text;
var exp_sess_intro_key_resp;
var exp_sess_trialClock;
var exp_fix_text;
var exp_num0;
var exp_numA;
var exp_numB;
var exp_num1;
var exp_num2;
var exp_num3;
var exp_num4;
var exp_number_key_resp;
var break_3Clock;
var newBlock_text;
var newBlock_key_resp;
var endClock;
var end_text;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "welcome"
  welcomeClock = new util.Clock();
  welcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'welcome_text',
    text: "Welcome to this numerical task!   You will be presented with four blocks of trials. In two of the blocks you will be asked if the digit is smaller or larger than 3.  In the other two blocks, you will be asked if the numerosity (The amount of digits present) is smaller/larger than 3.   Don't worry, you will get a chance to practice before the start of each block and you will be reminded of the instructions as well as how to respond.  When you are ready, press the spacebar to start.",
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  welcome_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  Prac_Instruction = new visual.TextStim({
    win: psychoJS.window,
    name: 'Prac_Instruction',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  instr_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "practice_trial"
  practice_trialClock = new util.Clock();
  fix_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'fix_text',
    text: '+',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  prac_num0 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_num0',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  prac_numA = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_numA',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -2.0 
  });
  
  prac_numB = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_numB',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -3.0 
  });
  
  prac_num1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_num1',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -4.0 
  });
  
  prac_num2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_num2',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -5.0 
  });
  
  prac_num3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_num3',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -6.0 
  });
  
  prac_num4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_num4',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -7.0 
  });
  
  practice_trial_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "practice_feed"
  practice_feedClock = new util.Clock();
  msg_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'msg_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "exp_intro"
  exp_introClock = new util.Clock();
  exp_intro_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_intro_text',
    text: 'Good! You have completed the practice trials for this block and will now do the real trials.  Remember, this time you will not be recieving feedback on your responses. Good luck!   Press the spacebar to begin.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  exp_sess_intro_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "exp_sess_trial"
  exp_sess_trialClock = new util.Clock();
  exp_fix_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_fix_text',
    text: '+',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  exp_num0 = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_num0',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  exp_numA = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_numA',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -2.0 
  });
  
  exp_numB = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_numB',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -3.0 
  });
  
  exp_num1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_num1',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -4.0 
  });
  
  exp_num2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_num2',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -5.0 
  });
  
  exp_num3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_num3',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -6.0 
  });
  
  exp_num4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'exp_num4',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -7.0 
  });
  
  exp_number_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "break_3"
  break_3Clock = new util.Clock();
  newBlock_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'newBlock_text',
    text: 'You have finished this block of trials. Well done! You will now be continuing on to the next block. Please press the spacebar when you are ready to begin the practice.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  newBlock_key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  end_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'end_text',
    text: 'Congratulations! \nYou have reached the end of study.  Thank you for your participation!',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.06,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var _welcome_key_resp_allKeys;
var welcomeComponents;
function welcomeRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'welcome'-------
    t = 0;
    welcomeClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    welcome_key_resp.keys = undefined;
    welcome_key_resp.rt = undefined;
    _welcome_key_resp_allKeys = [];
    // keep track of which components have finished
    welcomeComponents = [];
    welcomeComponents.push(welcome_text);
    welcomeComponents.push(welcome_key_resp);
    
    for (const thisComponent of welcomeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


var continueRoutine;
function welcomeRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'welcome'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = welcomeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *welcome_text* updates
    if (t >= 0.5 && welcome_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcome_text.tStart = t;  // (not accounting for frame time here)
      welcome_text.frameNStart = frameN;  // exact frame index
      
      welcome_text.setAutoDraw(true);
    }

    
    // *welcome_key_resp* updates
    if (t >= 0.5 && welcome_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcome_key_resp.tStart = t;  // (not accounting for frame time here)
      welcome_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { welcome_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { welcome_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { welcome_key_resp.clearEvents(); });
    }

    if (welcome_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = welcome_key_resp.getKeys({keyList: ['space'], waitRelease: false});
      _welcome_key_resp_allKeys = _welcome_key_resp_allKeys.concat(theseKeys);
      if (_welcome_key_resp_allKeys.length > 0) {
        welcome_key_resp.keys = _welcome_key_resp_allKeys[_welcome_key_resp_allKeys.length - 1].name;  // just the last key pressed
        welcome_key_resp.rt = _welcome_key_resp_allKeys[_welcome_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of welcomeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function welcomeRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'welcome'-------
    for (const thisComponent of welcomeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('welcome_key_resp.keys', welcome_key_resp.keys);
    if (typeof welcome_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('welcome_key_resp.rt', welcome_key_resp.rt);
        routineTimer.reset();
        }
    
    welcome_key_resp.stop();
    // the Routine "welcome" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var blocks;
var currentLoop;
function blocksLoopBegin(blocksLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  blocks = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: (("group" + expInfo["group"]) + ".xlsx"),
    seed: undefined, name: 'blocks'
  });
  psychoJS.experiment.addLoop(blocks); // add the loop to the experiment
  currentLoop = blocks;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisBlock of blocks) {
    const snapshot = blocks.getSnapshot();
    blocksLoopScheduler.add(importConditions(snapshot));
    blocksLoopScheduler.add(instructionsRoutineBegin(snapshot));
    blocksLoopScheduler.add(instructionsRoutineEachFrame(snapshot));
    blocksLoopScheduler.add(instructionsRoutineEnd(snapshot));
    const practice_trialsLoopScheduler = new Scheduler(psychoJS);
    blocksLoopScheduler.add(practice_trialsLoopBegin, practice_trialsLoopScheduler);
    blocksLoopScheduler.add(practice_trialsLoopScheduler);
    blocksLoopScheduler.add(practice_trialsLoopEnd);
    blocksLoopScheduler.add(exp_introRoutineBegin(snapshot));
    blocksLoopScheduler.add(exp_introRoutineEachFrame(snapshot));
    blocksLoopScheduler.add(exp_introRoutineEnd(snapshot));
    const exp_sess_trialsLoopScheduler = new Scheduler(psychoJS);
    blocksLoopScheduler.add(exp_sess_trialsLoopBegin, exp_sess_trialsLoopScheduler);
    blocksLoopScheduler.add(exp_sess_trialsLoopScheduler);
    blocksLoopScheduler.add(exp_sess_trialsLoopEnd);
    blocksLoopScheduler.add(break_3RoutineBegin(snapshot));
    blocksLoopScheduler.add(break_3RoutineEachFrame(snapshot));
    blocksLoopScheduler.add(break_3RoutineEnd(snapshot));
    blocksLoopScheduler.add(endLoopIteration(blocksLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


var practice_trials;
function practice_trialsLoopBegin(practice_trialsLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  practice_trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: order,
    seed: undefined, name: 'practice_trials'
  });
  psychoJS.experiment.addLoop(practice_trials); // add the loop to the experiment
  currentLoop = practice_trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisPractice_trial of practice_trials) {
    const snapshot = practice_trials.getSnapshot();
    practice_trialsLoopScheduler.add(importConditions(snapshot));
    practice_trialsLoopScheduler.add(practice_trialRoutineBegin(snapshot));
    practice_trialsLoopScheduler.add(practice_trialRoutineEachFrame(snapshot));
    practice_trialsLoopScheduler.add(practice_trialRoutineEnd(snapshot));
    practice_trialsLoopScheduler.add(practice_feedRoutineBegin(snapshot));
    practice_trialsLoopScheduler.add(practice_feedRoutineEachFrame(snapshot));
    practice_trialsLoopScheduler.add(practice_feedRoutineEnd(snapshot));
    practice_trialsLoopScheduler.add(endLoopIteration(practice_trialsLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function practice_trialsLoopEnd() {
  psychoJS.experiment.removeLoop(practice_trials);

  return Scheduler.Event.NEXT;
}


var exp_sess_trials;
function exp_sess_trialsLoopBegin(exp_sess_trialsLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  exp_sess_trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 3, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: order,
    seed: undefined, name: 'exp_sess_trials'
  });
  psychoJS.experiment.addLoop(exp_sess_trials); // add the loop to the experiment
  currentLoop = exp_sess_trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisExp_sess_trial of exp_sess_trials) {
    const snapshot = exp_sess_trials.getSnapshot();
    exp_sess_trialsLoopScheduler.add(importConditions(snapshot));
    exp_sess_trialsLoopScheduler.add(exp_sess_trialRoutineBegin(snapshot));
    exp_sess_trialsLoopScheduler.add(exp_sess_trialRoutineEachFrame(snapshot));
    exp_sess_trialsLoopScheduler.add(exp_sess_trialRoutineEnd(snapshot));
    exp_sess_trialsLoopScheduler.add(endLoopIteration(exp_sess_trialsLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function exp_sess_trialsLoopEnd() {
  psychoJS.experiment.removeLoop(exp_sess_trials);

  return Scheduler.Event.NEXT;
}


function blocksLoopEnd() {
  psychoJS.experiment.removeLoop(blocks);

  return Scheduler.Event.NEXT;
}


var _instr_key_resp_allKeys;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'instructions'-------
    t = 0;
    instructionsClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Prac_Instruction.setText(inst);
    instr_key_resp.keys = undefined;
    instr_key_resp.rt = undefined;
    _instr_key_resp_allKeys = [];
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(Prac_Instruction);
    instructionsComponents.push(instr_key_resp);
    
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function instructionsRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'instructions'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *Prac_Instruction* updates
    if (t >= 0.5 && Prac_Instruction.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Prac_Instruction.tStart = t;  // (not accounting for frame time here)
      Prac_Instruction.frameNStart = frameN;  // exact frame index
      
      Prac_Instruction.setAutoDraw(true);
    }

    
    // *instr_key_resp* updates
    if (t >= 1.0 && instr_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_key_resp.tStart = t;  // (not accounting for frame time here)
      instr_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { instr_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { instr_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { instr_key_resp.clearEvents(); });
    }

    if (instr_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = instr_key_resp.getKeys({keyList: ['space'], waitRelease: false});
      _instr_key_resp_allKeys = _instr_key_resp_allKeys.concat(theseKeys);
      if (_instr_key_resp_allKeys.length > 0) {
        instr_key_resp.keys = _instr_key_resp_allKeys[_instr_key_resp_allKeys.length - 1].name;  // just the last key pressed
        instr_key_resp.rt = _instr_key_resp_allKeys[_instr_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'instructions'-------
    for (const thisComponent of instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('instr_key_resp.keys', instr_key_resp.keys);
    if (typeof instr_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('instr_key_resp.rt', instr_key_resp.rt);
        routineTimer.reset();
        }
    
    instr_key_resp.stop();
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _practice_trial_key_resp_allKeys;
var practice_trialComponents;
function practice_trialRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'practice_trial'-------
    t = 0;
    practice_trialClock.reset(); // clock
    frameN = -1;
    routineTimer.add(4.500000);
    // update component parameters for each repeat
    prac_num0.setPos(eval(pos0));
    prac_num0.setText(number);
    prac_numA.setPos(eval(posA));
    prac_numA.setText(number);
    prac_numB.setPos(eval(posB));
    prac_numB.setText(number);
    prac_num1.setPos(eval(pos1));
    prac_num1.setText(number);
    prac_num2.setPos(eval(pos2));
    prac_num2.setText(number);
    prac_num3.setPos(eval(pos3));
    prac_num3.setText(number);
    prac_num4.setPos(eval(pos4));
    prac_num4.setText(number);
    practice_trial_key_resp.keys = undefined;
    practice_trial_key_resp.rt = undefined;
    _practice_trial_key_resp_allKeys = [];
    // keep track of which components have finished
    practice_trialComponents = [];
    practice_trialComponents.push(fix_text);
    practice_trialComponents.push(prac_num0);
    practice_trialComponents.push(prac_numA);
    practice_trialComponents.push(prac_numB);
    practice_trialComponents.push(prac_num1);
    practice_trialComponents.push(prac_num2);
    practice_trialComponents.push(prac_num3);
    practice_trialComponents.push(prac_num4);
    practice_trialComponents.push(practice_trial_key_resp);
    
    for (const thisComponent of practice_trialComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


var frameRemains;
function practice_trialRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'practice_trial'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = practice_trialClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fix_text* updates
    if (t >= 0.5 && fix_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fix_text.tStart = t;  // (not accounting for frame time here)
      fix_text.frameNStart = frameN;  // exact frame index
      
      fix_text.setAutoDraw(true);
    }

    frameRemains = 0.5 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (fix_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      fix_text.setAutoDraw(false);
    }
    
    // *prac_num0* updates
    if (t >= 1.5 && prac_num0.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_num0.tStart = t;  // (not accounting for frame time here)
      prac_num0.frameNStart = frameN;  // exact frame index
      
      prac_num0.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_num0.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_num0.setAutoDraw(false);
    }
    
    // *prac_numA* updates
    if (t >= 1.5 && prac_numA.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_numA.tStart = t;  // (not accounting for frame time here)
      prac_numA.frameNStart = frameN;  // exact frame index
      
      prac_numA.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_numA.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_numA.setAutoDraw(false);
    }
    
    // *prac_numB* updates
    if (t >= 1.5 && prac_numB.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_numB.tStart = t;  // (not accounting for frame time here)
      prac_numB.frameNStart = frameN;  // exact frame index
      
      prac_numB.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_numB.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_numB.setAutoDraw(false);
    }
    
    // *prac_num1* updates
    if (t >= 1.5 && prac_num1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_num1.tStart = t;  // (not accounting for frame time here)
      prac_num1.frameNStart = frameN;  // exact frame index
      
      prac_num1.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_num1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_num1.setAutoDraw(false);
    }
    
    // *prac_num2* updates
    if (t >= 1.5 && prac_num2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_num2.tStart = t;  // (not accounting for frame time here)
      prac_num2.frameNStart = frameN;  // exact frame index
      
      prac_num2.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_num2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_num2.setAutoDraw(false);
    }
    
    // *prac_num3* updates
    if (t >= 1.5 && prac_num3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_num3.tStart = t;  // (not accounting for frame time here)
      prac_num3.frameNStart = frameN;  // exact frame index
      
      prac_num3.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_num3.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_num3.setAutoDraw(false);
    }
    
    // *prac_num4* updates
    if (t >= 1.5 && prac_num4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_num4.tStart = t;  // (not accounting for frame time here)
      prac_num4.frameNStart = frameN;  // exact frame index
      
      prac_num4.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (prac_num4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      prac_num4.setAutoDraw(false);
    }
    
    // *practice_trial_key_resp* updates
    if (t >= 1.0 && practice_trial_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practice_trial_key_resp.tStart = t;  // (not accounting for frame time here)
      practice_trial_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { practice_trial_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { practice_trial_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { practice_trial_key_resp.clearEvents(); });
    }

    frameRemains = 1.0 + 3.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (practice_trial_key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      practice_trial_key_resp.status = PsychoJS.Status.FINISHED;
  }

    if (practice_trial_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = practice_trial_key_resp.getKeys({keyList: ['a', 'l'], waitRelease: false});
      _practice_trial_key_resp_allKeys = _practice_trial_key_resp_allKeys.concat(theseKeys);
      if (_practice_trial_key_resp_allKeys.length > 0) {
        practice_trial_key_resp.keys = _practice_trial_key_resp_allKeys[_practice_trial_key_resp_allKeys.length - 1].name;  // just the last key pressed
        practice_trial_key_resp.rt = _practice_trial_key_resp_allKeys[_practice_trial_key_resp_allKeys.length - 1].rt;
        // was this correct?
        if (practice_trial_key_resp.keys == correctkey) {
            practice_trial_key_resp.corr = 1;
        } else {
            practice_trial_key_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practice_trialComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practice_trialRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'practice_trial'-------
    for (const thisComponent of practice_trialComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (practice_trial_key_resp.keys === undefined) {
      if (['None','none',undefined].includes(correctkey)) {
         practice_trial_key_resp.corr = 1;  // correct non-response
      } else {
         practice_trial_key_resp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('practice_trial_key_resp.keys', practice_trial_key_resp.keys);
    psychoJS.experiment.addData('practice_trial_key_resp.corr', practice_trial_key_resp.corr);
    if (typeof practice_trial_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('practice_trial_key_resp.rt', practice_trial_key_resp.rt);
        routineTimer.reset();
        }
    
    practice_trial_key_resp.stop();
    return Scheduler.Event.NEXT;
  };
}


var practice_feedComponents;
function practice_feedRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'practice_feed'-------
    t = 0;
    practice_feedClock.reset(); // clock
    frameN = -1;
    routineTimer.add(1.000000);
    // update component parameters for each repeat
    msg_text.setText(msg);
    // keep track of which components have finished
    practice_feedComponents = [];
    practice_feedComponents.push(msg_text);
    
    for (const thisComponent of practice_feedComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function practice_feedRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'practice_feed'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = practice_feedClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *msg_text* updates
    if (t >= 0.0 && msg_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      msg_text.tStart = t;  // (not accounting for frame time here)
      msg_text.frameNStart = frameN;  // exact frame index
      
      msg_text.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (msg_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      msg_text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practice_feedComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practice_feedRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'practice_feed'-------
    for (const thisComponent of practice_feedComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    return Scheduler.Event.NEXT;
  };
}


var _exp_sess_intro_key_resp_allKeys;
var exp_introComponents;
function exp_introRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'exp_intro'-------
    t = 0;
    exp_introClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    exp_sess_intro_key_resp.keys = undefined;
    exp_sess_intro_key_resp.rt = undefined;
    _exp_sess_intro_key_resp_allKeys = [];
    // keep track of which components have finished
    exp_introComponents = [];
    exp_introComponents.push(exp_intro_text);
    exp_introComponents.push(exp_sess_intro_key_resp);
    
    for (const thisComponent of exp_introComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function exp_introRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'exp_intro'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = exp_introClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *exp_intro_text* updates
    if (t >= 0.5 && exp_intro_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_intro_text.tStart = t;  // (not accounting for frame time here)
      exp_intro_text.frameNStart = frameN;  // exact frame index
      
      exp_intro_text.setAutoDraw(true);
    }

    
    // *exp_sess_intro_key_resp* updates
    if (t >= 0.5 && exp_sess_intro_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_sess_intro_key_resp.tStart = t;  // (not accounting for frame time here)
      exp_sess_intro_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { exp_sess_intro_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { exp_sess_intro_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { exp_sess_intro_key_resp.clearEvents(); });
    }

    if (exp_sess_intro_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = exp_sess_intro_key_resp.getKeys({keyList: ['space'], waitRelease: false});
      _exp_sess_intro_key_resp_allKeys = _exp_sess_intro_key_resp_allKeys.concat(theseKeys);
      if (_exp_sess_intro_key_resp_allKeys.length > 0) {
        exp_sess_intro_key_resp.keys = _exp_sess_intro_key_resp_allKeys[_exp_sess_intro_key_resp_allKeys.length - 1].name;  // just the last key pressed
        exp_sess_intro_key_resp.rt = _exp_sess_intro_key_resp_allKeys[_exp_sess_intro_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of exp_introComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function exp_introRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'exp_intro'-------
    for (const thisComponent of exp_introComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('exp_sess_intro_key_resp.keys', exp_sess_intro_key_resp.keys);
    if (typeof exp_sess_intro_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('exp_sess_intro_key_resp.rt', exp_sess_intro_key_resp.rt);
        routineTimer.reset();
        }
    
    exp_sess_intro_key_resp.stop();
    // the Routine "exp_intro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _exp_number_key_resp_allKeys;
var exp_sess_trialComponents;
function exp_sess_trialRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'exp_sess_trial'-------
    t = 0;
    exp_sess_trialClock.reset(); // clock
    frameN = -1;
    routineTimer.add(4.500000);
    // update component parameters for each repeat
    exp_num0.setPos(eval(pos0));
    exp_num0.setText(number);
    exp_numA.setPos(eval(posA));
    exp_numA.setText(number);
    exp_numB.setPos(eval(posB));
    exp_numB.setText(number);
    exp_num1.setPos(eval(pos1));
    exp_num1.setText(number);
    exp_num2.setPos(eval(pos2));
    exp_num2.setText(number);
    exp_num3.setPos(eval(pos3));
    exp_num3.setText(number);
    exp_num4.setPos(eval(pos4));
    exp_num4.setText(number);
    exp_number_key_resp.keys = undefined;
    exp_number_key_resp.rt = undefined;
    _exp_number_key_resp_allKeys = [];
    // keep track of which components have finished
    exp_sess_trialComponents = [];
    exp_sess_trialComponents.push(exp_fix_text);
    exp_sess_trialComponents.push(exp_num0);
    exp_sess_trialComponents.push(exp_numA);
    exp_sess_trialComponents.push(exp_numB);
    exp_sess_trialComponents.push(exp_num1);
    exp_sess_trialComponents.push(exp_num2);
    exp_sess_trialComponents.push(exp_num3);
    exp_sess_trialComponents.push(exp_num4);
    exp_sess_trialComponents.push(exp_number_key_resp);
    
    for (const thisComponent of exp_sess_trialComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function exp_sess_trialRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'exp_sess_trial'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = exp_sess_trialClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *exp_fix_text* updates
    if (t >= 0.5 && exp_fix_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_fix_text.tStart = t;  // (not accounting for frame time here)
      exp_fix_text.frameNStart = frameN;  // exact frame index
      
      exp_fix_text.setAutoDraw(true);
    }

    frameRemains = 0.5 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_fix_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_fix_text.setAutoDraw(false);
    }
    
    // *exp_num0* updates
    if (t >= 1.5 && exp_num0.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_num0.tStart = t;  // (not accounting for frame time here)
      exp_num0.frameNStart = frameN;  // exact frame index
      
      exp_num0.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_num0.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_num0.setAutoDraw(false);
    }
    
    // *exp_numA* updates
    if (t >= 1.5 && exp_numA.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_numA.tStart = t;  // (not accounting for frame time here)
      exp_numA.frameNStart = frameN;  // exact frame index
      
      exp_numA.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_numA.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_numA.setAutoDraw(false);
    }
    
    // *exp_numB* updates
    if (t >= 1.5 && exp_numB.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_numB.tStart = t;  // (not accounting for frame time here)
      exp_numB.frameNStart = frameN;  // exact frame index
      
      exp_numB.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_numB.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_numB.setAutoDraw(false);
    }
    
    // *exp_num1* updates
    if (t >= 1.5 && exp_num1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_num1.tStart = t;  // (not accounting for frame time here)
      exp_num1.frameNStart = frameN;  // exact frame index
      
      exp_num1.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_num1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_num1.setAutoDraw(false);
    }
    
    // *exp_num2* updates
    if (t >= 1.5 && exp_num2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_num2.tStart = t;  // (not accounting for frame time here)
      exp_num2.frameNStart = frameN;  // exact frame index
      
      exp_num2.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_num2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_num2.setAutoDraw(false);
    }
    
    // *exp_num3* updates
    if (t >= 1.5 && exp_num3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_num3.tStart = t;  // (not accounting for frame time here)
      exp_num3.frameNStart = frameN;  // exact frame index
      
      exp_num3.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_num3.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_num3.setAutoDraw(false);
    }
    
    // *exp_num4* updates
    if (t >= 1.5 && exp_num4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_num4.tStart = t;  // (not accounting for frame time here)
      exp_num4.frameNStart = frameN;  // exact frame index
      
      exp_num4.setAutoDraw(true);
    }

    frameRemains = 1.5 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_num4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_num4.setAutoDraw(false);
    }
    
    // *exp_number_key_resp* updates
    if (t >= 1.0 && exp_number_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exp_number_key_resp.tStart = t;  // (not accounting for frame time here)
      exp_number_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { exp_number_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { exp_number_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { exp_number_key_resp.clearEvents(); });
    }

    frameRemains = 1.0 + 3.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (exp_number_key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      exp_number_key_resp.status = PsychoJS.Status.FINISHED;
  }

    if (exp_number_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = exp_number_key_resp.getKeys({keyList: ['a', 'l'], waitRelease: false});
      _exp_number_key_resp_allKeys = _exp_number_key_resp_allKeys.concat(theseKeys);
      if (_exp_number_key_resp_allKeys.length > 0) {
        exp_number_key_resp.keys = _exp_number_key_resp_allKeys[_exp_number_key_resp_allKeys.length - 1].name;  // just the last key pressed
        exp_number_key_resp.rt = _exp_number_key_resp_allKeys[_exp_number_key_resp_allKeys.length - 1].rt;
        // was this correct?
        if (exp_number_key_resp.keys == correctkey) {
            exp_number_key_resp.corr = 1;
        } else {
            exp_number_key_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of exp_sess_trialComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function exp_sess_trialRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'exp_sess_trial'-------
    for (const thisComponent of exp_sess_trialComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (exp_number_key_resp.keys === undefined) {
      if (['None','none',undefined].includes(correctkey)) {
         exp_number_key_resp.corr = 1;  // correct non-response
      } else {
         exp_number_key_resp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('exp_number_key_resp.keys', exp_number_key_resp.keys);
    psychoJS.experiment.addData('exp_number_key_resp.corr', exp_number_key_resp.corr);
    if (typeof exp_number_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('exp_number_key_resp.rt', exp_number_key_resp.rt);
        routineTimer.reset();
        }
    
    exp_number_key_resp.stop();
    return Scheduler.Event.NEXT;
  };
}


var _newBlock_key_resp_allKeys;
var break_3Components;
function break_3RoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'break_3'-------
    t = 0;
    break_3Clock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    newBlock_key_resp.keys = undefined;
    newBlock_key_resp.rt = undefined;
    _newBlock_key_resp_allKeys = [];
    // keep track of which components have finished
    break_3Components = [];
    break_3Components.push(newBlock_text);
    break_3Components.push(newBlock_key_resp);
    
    for (const thisComponent of break_3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function break_3RoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'break_3'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = break_3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *newBlock_text* updates
    if (t >= 0.5 && newBlock_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      newBlock_text.tStart = t;  // (not accounting for frame time here)
      newBlock_text.frameNStart = frameN;  // exact frame index
      
      newBlock_text.setAutoDraw(true);
    }

    
    // *newBlock_key_resp* updates
    if (t >= 0.5 && newBlock_key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      newBlock_key_resp.tStart = t;  // (not accounting for frame time here)
      newBlock_key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { newBlock_key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { newBlock_key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { newBlock_key_resp.clearEvents(); });
    }

    if (newBlock_key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = newBlock_key_resp.getKeys({keyList: ['space'], waitRelease: false});
      _newBlock_key_resp_allKeys = _newBlock_key_resp_allKeys.concat(theseKeys);
      if (_newBlock_key_resp_allKeys.length > 0) {
        newBlock_key_resp.keys = _newBlock_key_resp_allKeys[_newBlock_key_resp_allKeys.length - 1].name;  // just the last key pressed
        newBlock_key_resp.rt = _newBlock_key_resp_allKeys[_newBlock_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of break_3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function break_3RoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'break_3'-------
    for (const thisComponent of break_3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('newBlock_key_resp.keys', newBlock_key_resp.keys);
    if (typeof newBlock_key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('newBlock_key_resp.rt', newBlock_key_resp.rt);
        routineTimer.reset();
        }
    
    newBlock_key_resp.stop();
    // the Routine "break_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var endComponents;
function endRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'end'-------
    t = 0;
    endClock.reset(); // clock
    frameN = -1;
    routineTimer.add(10.500000);
    // update component parameters for each repeat
    // keep track of which components have finished
    endComponents = [];
    endComponents.push(end_text);
    
    for (const thisComponent of endComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    
    return Scheduler.Event.NEXT;
  };
}


function endRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'end'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *end_text* updates
    if (t >= 0.5 && end_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      end_text.tStart = t;  // (not accounting for frame time here)
      end_text.frameNStart = frameN;  // exact frame index
      
      end_text.setAutoDraw(true);
    }

    frameRemains = 0.5 + 10 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (end_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      end_text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of endComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'end'-------
    for (const thisComponent of endComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        const thisTrial = snapshot.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(snapshot);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(currentLoop) {
  return function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
